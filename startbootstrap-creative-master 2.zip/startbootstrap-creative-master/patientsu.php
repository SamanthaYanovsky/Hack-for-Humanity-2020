<!DOCTYPE html>
<html lang="en">
<?php

//connect to the database
$conn = mysqli_connect('localhost','root','', '8888')

?>


<form action= patientsu.php>
  <h1>Sign Up</h1>
  <p>Please fill in this form to create an account.</p>
  <p>
  <label for="fName"><b>First Name</b></label>
  <input type="text" name="fName" required>
</p>
<p>
  <label for="lName"><b>Last Name</b></label>
  <input type="text"  name="lName" required>
</p>
<p>
  <label for="email"><b>Email</b></label>
  <input type="text"  name="email" required>
</p>
<p>
  <label for="state"><b>State</b></label>
  <input type="text"  name="state" required>
</p>
<p>
  <label for="country"><b>Country</b></label>
  <input type="text"  name="country" required>
</p>
<p>
  <label for="uName"><b>Username</b></label>
  <input type="text"  name="uName" required>
</p>
</p>
  <label for="psw"><b>Password</b></label>
  <input type="password" name="psw" required>
</form>
</html>

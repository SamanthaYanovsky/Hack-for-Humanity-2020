<!DOCTYPE html>
<html lang="en">
<?php

//connect to the database
$conn = mysqli_connect('localhost','root','', '8888')

?>


<form action= loginpat.php>
  <h1>Login</h1>


<p>
  <label for="uName"><b>Username</b></label>
  <input type="text"  name="uName" required>
</p>
</p>
  <label for="psw"><b>Password</b></label>
  <input type="password" name="psw" required>
</form>
</html>

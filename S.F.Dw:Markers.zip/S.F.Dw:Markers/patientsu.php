<?php ob_start(); ?>

<!DOCTYPE html>
<html lang="en">
<?php

$message = '';
//connect to the database

$servername = "127.0.0.1";
$username = "root";
$pass = "root";


 $db =  mysqli_connect($servername,$username,$pass, "H4H-S.F.D");

 if($db->connet_error)
 {
   $message = $db->connect_error;
 }
 else {
     echo $message;
 }
?>


<form action= patientsu.php method = "POST">
  <h1>Sign Up</h1>
  <p>Please fill in this form to create an account.</p>
  <p>
  <label for="fName"><b>First Name</b></label>
  <input type="text" name="fName" required>
  <?php  $fName = $_POST['fName']; ?>


</p>
<p>
  <label for="lName"><b>Last Name</b></label>
  <input type="text"  name="lName" required>
  <?php  $lName = $_POST['lName']; ?>
</p>
<p>
  <label for="email"><b>Email</b></label>
  <input type="text"  name="email" required>
  <?php  $email = $_POST['email']; ?>
</p>
<p>
  <label for="Latitude"><b>Latitude</b></label>
  <input type="text"  name="Latitude" required>
  <?php  $Latitude = $_POST['Latitude']; ?>
</p>
<p>
  <label for="Longitude"><b>Longitude</b></label>
  <input type="text" name="Longitude" required>
  <?php  $Longitude = $_POST['Longitude']; ?>
</p>
<p>
  <label for="uName"><b>Username</b></label>
  <input type="text"   name="uName" required>
  <?php  $uName = $_POST['uName']; ?>
</p>
</p>
  <label for="psw"><b>Password</b></label>
  <input type="password" name="psw" required>
  <?php  $psw = $_POST['psw']; ?>
<p>
<input type = "submit" value = "submit" name = "submit">
</p>

<?php

  if(isset($_POST['submit'])){
    $sql= "INSERT INTO meminfo" . "(LastName,FirstName,Email, Longitude,Latitude,Username,Pass) " . " VALUES ('". $lName ."', '". $fName ."', '". $email ."',   ".$Longitude." , ".$Latitude." ,'". $uName ."', '". $psw ."')" ;
    if (mysqli_query($db, $sql))
    {
      header('Location: index.html');
    }else {
      echo "Error";
    }
  }

 ?>
</form>

</html>

<!DOCTYPE html>
<html lang="en">
<?php
$message = '';
//connect to the database

$servername = "127.0.0.1";
$username = "root";
$pass = "root";


 $db =  mysqli_connect($servername,$username,$pass, "H4H-S.F.D");

 if($db->connet_error)
 {
   $message = $db->connect_error;
 }
 else {
     echo $message;
 }
?>


<form action= loginpat.php method = "POST">
  <h1>Login</h1>


<p>
  <label for="uName"><b>Username</b></label>
  <input type="text"  name="uName" required>
</p>
</p>
  <label for="psw"><b>Password</b></label>
  <input type="password" name="psw" required>
  <p>
  <input type = "submit" value = "submit">
  
  </p>
</form>
</html>
